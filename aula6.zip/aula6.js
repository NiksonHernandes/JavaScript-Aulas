/*var cidade = prompt('Informe uma cidade:');

switch (cidade) {
	case 'Taquaritinga':
		alert('Taquaritinga');
		break;
	case 'Monte Alto':
		alert('Monte Alto');
		break;
	case 'Jaboticabal':
	case 'Dobrada':
		alert('Jaboticabal ou Dobrada');
		break;
	default:
		alert('Outra cidade!');
}*/

/*var numero = prompt('Informe um número:');

if (isNaN(numero)) {
	alert('O valor informado não é um número!');
} else {
	numero = parseInt(numero);

	while (numero < 10) {
		console.log(numero);
		numero++;
	}

	do {
		console.log(numero);
		numero++;		
	} while (numero < 10);

	for (var i = 0; i < numero; i++) {
		console.log(i);
	}

	for (item in document) {
		console.log(item);
	}
}*/

/*var numero1;
var numero2;
var operacao;
var repetir = 's';

while (repetir == 's') {
	numero1 = prompt('Informe o número1:');

	switch (operacao) {
		case '+':
			break;
		case '-':
			break;
	}

	repetir = prompt('Deseja repetir o cálculo (s = sim)?');
}


do {
	numero1 = prompt('Informe o número 1:');

	if (operacao == '+') {

	}
} while (confirm('Deseja repetir o cálculo?'));*/

//                        0             1             2
var listaCidades = ['Taquaritinga','Monte Alto','Jaboticabal'];

// Adicionar elementos no array
listaCidades.push('Matão');
listaCidades.push('Araraquara');
listaCidades.push('Itápolis');

// Remover último elemento do array
listaCidades.pop();

// Remover determinado elemento do array
listaCidades.splice(2, 1);

// Alteração de determinado elemento do array
listaCidades[1] = 'Sertãozinho';

// Exibir itens do array
var totalElementos = listaCidades.length;
var aux = '';
for (var i = 0; i < totalElementos; i++) {
	aux += listaCidades[i] +'<br />';
}
document.write(aux);

var matriz = [];
matriz.push(['1a','1b','1c']);
matriz.push(['2a','2b','2c']);
matriz.push(['3a','3b','3c']);
var aux2 = '<br /><br />';
aux2 += '<table border="1">';
for (var lin = 0; lin < matriz.length; lin++) {
	aux2 += '<tr>';
	for (var col = 0; col < matriz[lin].length; col++) {
		aux2 += '<td>'+ matriz[lin][col] +'</td>';
	}
	aux2 += '</tr>';
}
aux2 += '</table>';
document.write(aux2);